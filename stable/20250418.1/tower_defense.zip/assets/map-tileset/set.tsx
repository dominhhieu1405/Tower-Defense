<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="set" tilewidth="64" tileheight="64" tilecount="256" columns="16">
 <image source="set.png" width="1024" height="1024"/>
</tileset>
