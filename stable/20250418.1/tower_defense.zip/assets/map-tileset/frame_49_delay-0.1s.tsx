<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="frame_49_delay-0.1s" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="../../../../Pictures/_cover/frame_49_delay-0.1s.png" width="512" height="512"/>
</tileset>
